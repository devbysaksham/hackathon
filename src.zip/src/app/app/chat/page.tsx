'use client';

import React from 'react';
import AIChatBox from '@/components/AIChatBox';

export default function AppChatPage() {
    return (
        <div className="flex flex-col h-[calc(100vh-210px)] min-h-[560px] bg-white/80 dark:bg-slate-950/80 backdrop-blur-2xl rounded-[28px] overflow-hidden border border-slate-200/70 dark:border-slate-800 shadow-2xl shadow-indigo-500/5 relative animate-fade-in-up">
            <AIChatBox className="h-full border-none shadow-none rounded-none bg-transparent dark:bg-transparent" />
        </div>
    );
}
