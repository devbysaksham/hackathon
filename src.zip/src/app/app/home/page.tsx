'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAppStore } from '@/store/useAppStore';
import API from '@/lib/api';
import { SectionHeader } from '@/components/app/SectionHeader';
import {
    MessageSquare, Calendar, FolderHeart, Pill, Activity,
    Search, Loader2, HeartPulse, Droplets, ArrowRight, Stethoscope,
    TrendingUp, ShieldCheck, Sparkles, ChevronRight
} from 'lucide-react';
import { toast } from 'sonner';

export default function AppHomePage() {
    const router = useRouter();
    const { user, token } = useAppStore();
    const [patientFile, setPatientFile] = useState<any>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        if (!token || !user) { router.push('/login'); return; }
        loadPatientFile();
    }, [user, token]);

    const loadPatientFile = async () => {
        if (!user) return;
        try {
            const res = await API.get(`/patients/${user.id}/file`);
            setPatientFile(res.data.data);
        } catch (err: any) {
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    const quickActions = [
        { name: 'AI Chat', icon: MessageSquare, href: '/app/chat', gradient: 'from-indigo-500 to-violet-600', shadow: 'shadow-indigo-500/30', label: 'Ask AI' },
        { name: 'Records', icon: FolderHeart, href: '/app/records', gradient: 'from-violet-500 to-purple-600', shadow: 'shadow-violet-500/30', label: 'Health' },
        { name: 'Medicines', icon: Pill, href: '/app/medicines', gradient: 'from-orange-400 to-rose-500', shadow: 'shadow-orange-400/30', label: 'Rx' },
        { name: 'Visits', icon: Calendar, href: '/app/appointments', gradient: 'from-teal-500 to-emerald-500', shadow: 'shadow-teal-500/30', label: 'Appt.' },
    ];

    const specializations = [
        { name: 'Neurology', icon: '🧠' },
        { name: 'Cardiology', icon: '🫀' },
        { name: 'Orthopedics', icon: '🦴' },
        { name: 'Pulmonology', icon: '🫁' },
        { name: 'Dentistry', icon: '🦷' },
        { name: 'Ophthalmology', icon: '👁️' },
    ];

    const healthTips = [
        { icon: '💧', tip: 'Stay hydrated — 8 glasses daily' },
        { icon: '🏃', tip: 'Walk 30 minutes every day' },
        { icon: '🥗', tip: 'Eat fruits & vegetables daily' },
    ];

    if (isLoading) {
        return (
            <div className="flex flex-col items-center justify-center h-[60vh] gap-4">
                <div className="relative">
                    <div className="h-16 w-16 rounded-full bg-gradient-to-br from-indigo-100 to-violet-100 flex items-center justify-center">
                        <Loader2 className="h-7 w-7 text-indigo-500 animate-spin" />
                    </div>
                    <div className="absolute inset-0 rounded-full bg-indigo-200/30 animate-ping" />
                </div>
                <p className="text-sm font-semibold text-slate-400">Loading your health dashboard...</p>
            </div>
        );
    }

    const appointments = patientFile?.appointments || [];
    const todayStr = new Date().toISOString().split('T')[0];
    const upcomingApps = appointments.filter((app: any) =>
        app.appointment_date >= todayStr &&
        (app.appointment_status === 'confirmed' || app.appointment_status === 'pending')
    );

    return (
        <div className="space-y-5">
            {/* Search Bar */}
            <div className="relative group">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-[18px] w-[18px] text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
                <input
                    placeholder="Search doctors, symptoms, medicines..."
                    className="w-full pl-11 pr-4 h-[50px] rounded-2xl bg-white/80 dark:bg-slate-900/80 border border-slate-200/60 dark:border-slate-800 shadow-sm text-[14px] font-medium placeholder:text-slate-400 placeholder:font-normal focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all backdrop-blur-sm"
                />
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-4 gap-3">
                {quickActions.map((action) => (
                    <Link key={action.name} href={action.href} className="flex flex-col items-center gap-2 group">
                        <div className={`h-[58px] w-[58px] rounded-[18px] bg-gradient-to-br ${action.gradient} flex items-center justify-center shadow-lg ${action.shadow} transition-all duration-300 group-hover:scale-105 group-active:scale-95`}>
                            <action.icon className="h-[22px] w-[22px] text-white" strokeWidth={2} />
                        </div>
                        <span className="text-[11px] font-bold text-slate-600 dark:text-slate-300">{action.name}</span>
                    </Link>
                ))}
            </div>

            {/* Hero Health Card */}
            <div className="relative overflow-hidden rounded-[26px] bg-gradient-to-br from-indigo-600 via-violet-600 to-purple-700 p-5 shadow-2xl shadow-indigo-500/25 text-white">
                {/* Decorative elements */}
                <div className="absolute -top-10 -right-10 w-36 h-36 bg-white/10 rounded-full blur-2xl" />
                <div className="absolute -bottom-6 -left-6 w-24 h-24 bg-violet-400/20 rounded-full blur-xl" />
                <div className="absolute top-4 right-4 w-3 h-3 rounded-full bg-white/30" />
                <div className="absolute top-8 right-10 w-1.5 h-1.5 rounded-full bg-white/20" />

                <div className="relative z-10">
                    <div className="flex items-start justify-between mb-4">
                        <div>
                            <div className="flex items-center gap-2 mb-1">
                                <ShieldCheck className="h-4 w-4 text-white/80" />
                                <span className="text-[10px] font-bold tracking-widest uppercase text-white/70">Health Status</span>
                            </div>
                            <p className="text-[28px] font-extrabold text-white leading-tight">All Good! ✨</p>
                        </div>
                        <div className="h-12 w-12 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center">
                            <Activity className="h-6 w-6 text-white" strokeWidth={2} />
                        </div>
                    </div>
                    
                    <div className="flex gap-2.5">
                        <div className="flex items-center gap-2 bg-white/15 backdrop-blur-sm px-3 py-2 rounded-xl border border-white/10">
                            <HeartPulse className="h-4 w-4 text-rose-200" />
                            <div>
                                <p className="text-[10px] text-white/60 font-medium leading-none">Heart Rate</p>
                                <p className="text-[13px] font-bold text-white mt-0.5">72 bpm</p>
                            </div>
                        </div>
                        <div className="flex items-center gap-2 bg-white/15 backdrop-blur-sm px-3 py-2 rounded-xl border border-white/10">
                            <Droplets className="h-4 w-4 text-blue-200" />
                            <div>
                                <p className="text-[10px] text-white/60 font-medium leading-none">Blood Group</p>
                                <p className="text-[13px] font-bold text-white mt-0.5">B+</p>
                            </div>
                        </div>
                        <div className="flex items-center gap-2 bg-white/15 backdrop-blur-sm px-3 py-2 rounded-xl border border-white/10">
                            <TrendingUp className="h-4 w-4 text-green-200" />
                            <div>
                                <p className="text-[10px] text-white/60 font-medium leading-none">BMI</p>
                                <p className="text-[13px] font-bold text-white mt-0.5">22.4</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Upcoming Appointment Banner */}
            {upcomingApps.length > 0 && (
                <div className="rounded-2xl bg-gradient-to-r from-teal-50 to-emerald-50 dark:from-teal-900/20 dark:to-emerald-900/20 border border-teal-100 dark:border-teal-800/40 p-4 flex items-center gap-4">
                    <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-teal-500 to-emerald-500 flex items-center justify-center shrink-0 shadow-md shadow-teal-500/20">
                        <Calendar className="h-5 w-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                        <p className="text-[11px] font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400">Upcoming</p>
                        <p className="text-[13px] font-bold text-slate-800 dark:text-white truncate mt-0.5">
                            {upcomingApps[0].appointment_date} · {upcomingApps[0].appointment_time}
                        </p>
                    </div>
                    <Link href="/app/appointments" className="h-8 w-8 rounded-xl bg-teal-500 flex items-center justify-center shrink-0">
                        <ChevronRight className="h-4 w-4 text-white" />
                    </Link>
                </div>
            )}

            {/* Specialists Horizontal Scroll */}
            <div>
                <SectionHeader title="Find Specialists" actionText="See All" actionHref="/app/appointments" />
                <div className="flex overflow-x-auto pb-1 gap-3 scrollbar-none -mx-1 px-1">
                    {specializations.map((spec) => (
                        <Link key={spec.name} href={`/app/chat`} className="flex flex-col items-center gap-2 min-w-[72px] cursor-pointer group">
                            <div className="h-[68px] w-[68px] rounded-[20px] bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 shadow-sm flex items-center justify-center text-2xl group-hover:scale-105 group-hover:shadow-md group-hover:border-indigo-200 dark:group-hover:border-indigo-800 transition-all duration-200">
                                {spec.icon}
                            </div>
                            <span className="text-[10px] font-bold text-slate-600 dark:text-slate-400 text-center leading-tight">{spec.name}</span>
                        </Link>
                    ))}
                </div>
            </div>

            {/* Health Tips */}
            <div>
                <SectionHeader title="Today's Tips" />
                <div className="space-y-2.5">
                    {healthTips.map((tip, i) => (
                        <div key={i} className="flex items-center gap-3 bg-white/70 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800 rounded-2xl px-4 py-3 backdrop-blur-sm">
                            <span className="text-xl">{tip.icon}</span>
                            <p className="text-[13px] font-semibold text-slate-700 dark:text-slate-300">{tip.tip}</p>
                        </div>
                    ))}
                </div>
            </div>

            {/* AI Banner */}
            <Link href="/app/chat" className="block">
                <div className="relative overflow-hidden rounded-[22px] bg-gradient-to-br from-slate-900 to-slate-800 dark:from-slate-800 dark:to-slate-900 p-4 border border-slate-700/50 group hover:scale-[1.01] active:scale-[0.99] transition-all duration-200">
                    <div className="absolute -top-6 -right-6 w-24 h-24 bg-indigo-500/20 rounded-full blur-xl" />
                    <div className="relative z-10 flex items-center gap-4">
                        <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shrink-0 shadow-lg shadow-indigo-500/30">
                            <Sparkles className="h-5 w-5 text-white" />
                        </div>
                        <div className="flex-1">
                            <p className="font-bold text-white text-[14px]">AI Health Assistant</p>
                            <p className="text-slate-400 text-[11px] font-medium mt-0.5">Ask anything about your health, symptoms, or medicines</p>
                        </div>
                        <ArrowRight className="h-5 w-5 text-slate-500 group-hover:text-indigo-400 transition-colors" />
                    </div>
                </div>
            </Link>

            <div className="h-4" />
        </div>
    );
}
