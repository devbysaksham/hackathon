import React from "react";
import { cn } from "@/lib/utils";

interface MobileContainerProps {
  children: React.ReactNode;
  className?: string;
  isDashboard?: boolean;
}

export function MobileContainer({ children, className, isDashboard = false }: MobileContainerProps) {
  if (isDashboard) {
    return <div className={cn("w-full h-full", className)}>{children}</div>;
  }

  return (
    <div className="h-full w-full flex justify-center relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #f0f4ff 0%, #faf5ff 50%, #f0fdf4 100%)' }}>
      {/* Ambient blobs */}
      <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] rounded-full bg-indigo-400/10 blur-3xl pointer-events-none" />
      <div className="absolute bottom-[-5%] right-[-5%] w-[50%] h-[50%] rounded-full bg-violet-400/10 blur-3xl pointer-events-none" />
      <div className="absolute top-[40%] left-[30%] w-[40%] h-[40%] rounded-full bg-teal-400/8 blur-3xl pointer-events-none" />

      <div
        className={cn(
          "w-full h-full sm:max-w-md sm:max-h-[calc(100dvh-3rem)] relative overflow-hidden max-w-[100vw]",
          "bg-white/50 dark:bg-slate-950/80",
          "sm:border sm:border-white/80 dark:sm:border-slate-800",
          "sm:rounded-[2.5rem] sm:shadow-2xl sm:shadow-indigo-200/30 dark:sm:shadow-none",
          "sm:my-6 backdrop-blur-sm",
          "flex flex-col mx-auto",
          className
        )}
      >
        {children}
      </div>
    </div>
  );
}
