'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, MessageSquare, Calendar, FolderHeart, Pill, User } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function BottomNav() {
    const pathname = usePathname();

    const navItems = [
        { name: 'Home', path: '/app/home', icon: Home },
        { name: 'Chat', path: '/app/chat', icon: MessageSquare },
        { name: 'Visits', path: '/app/appointments', icon: Calendar },
        { name: 'Records', path: '/app/records', icon: FolderHeart },
        { name: 'Rx', path: '/app/medicines', icon: Pill },
        { name: 'Me', path: '/app/profile', icon: User },
    ];

    return (
        <div className="backdrop-blur-3xl bg-white/90 dark:bg-slate-900/90 border border-slate-100/80 dark:border-slate-700/40 shadow-[0_-2px_40px_rgba(99,102,241,0.08)] rounded-[2.5rem] px-2 py-2 flex items-center justify-between mx-auto max-w-sm relative overflow-hidden">
            {/* Ambient glow */}
            <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/[0.03] via-transparent to-violet-500/[0.03] pointer-events-none" />
            
            {navItems.map((item) => {
                const isActive = pathname.startsWith(item.path);
                return (
                    <Link
                        key={item.path}
                        href={item.path}
                        className={cn(
                            "relative flex flex-col items-center justify-center w-[3.2rem] h-[3.5rem] rounded-[1.2rem] transition-all duration-300 gap-1 z-10",
                            isActive
                                ? "text-white"
                                : "text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
                        )}
                    >
                        {isActive && (
                            <span className="absolute inset-0 rounded-[1.2rem] bg-gradient-to-br from-indigo-500 to-violet-600 shadow-lg shadow-indigo-500/30" />
                        )}
                        <item.icon className={cn(
                            "h-[18px] w-[18px] transition-all duration-300 relative z-10",
                            isActive ? "stroke-[2px] scale-110 drop-shadow-sm" : "stroke-[1.5px]"
                        )} />
                        <span className={cn(
                            "text-[9px] tracking-tight transition-all duration-200 relative z-10",
                            isActive ? "font-bold" : "font-medium opacity-70"
                        )}>
                            {item.name}
                        </span>
                    </Link>
                );
            })}
        </div>
    );
}
