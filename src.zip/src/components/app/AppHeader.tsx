'use client';

import React, { useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useAppStore } from '@/store/useAppStore';
import API from '@/lib/api';
import { Bell, User as UserIcon, ArrowLeft } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from '@/components/ui/button';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function AppHeader() {
    const { user, logout, setUser } = useAppStore();
    const router = useRouter();
    const pathname = usePathname();

    useEffect(() => {
        if (user?.id && user.role === 'patient' && !user.phone) {
            API.get(`/auth/me`).then(res => {
                if (res.data?.data) {
                    setUser({ ...user, ...res.data.data });
                }
            }).catch(() => {});
        }
    }, [user?.id]);

    const handleLogout = () => {
        logout();
        router.push('/login');
    };

    function getInitials(name?: string) {
        if (!name) return 'A';
        return name.trim().split(' ').map(p => p[0]).join('').toUpperCase().slice(0, 2);
    }

    const bottomNavRoutes = ['/app/home', '/app/chat', '/app/appointments', '/app/records', '/app/medicines', '/app/profile', '/app'];
    const isRootNode = bottomNavRoutes.some(route => pathname === route || pathname === '/app');
    const isHome = pathname === '/app/home' || pathname === '/app';
    const showBack = !isRootNode;

    const getPageTitle = () => {
        if (pathname.includes('/chat')) return 'AI Health Assistant';
        if (pathname.includes('/appointments')) return 'My Appointments';
        if (pathname.includes('/records')) return 'Health Records';
        if (pathname.includes('/medicines')) return 'Medicines';
        if (pathname.includes('/profile')) return 'My Profile';
        return '';
    };

    const timeOfDay = () => {
        const h = new Date().getHours();
        if (h < 12) return 'Good Morning';
        if (h < 17) return 'Good Afternoon';
        return 'Good Evening';
    };

    return (
        <header className="sticky top-0 z-40 w-full h-[68px] flex items-center justify-between px-5 shrink-0">
            {/* Glass background */}
            <div className="absolute inset-0 backdrop-blur-2xl bg-white/80 dark:bg-slate-950/80 border-b border-white/60 dark:border-slate-800/60 shadow-[0_1px_0_0_rgba(0,0,0,0.04)]" />
            
            <div className="relative z-10 flex items-center gap-3">
                {showBack ? (
                    <>
                        <button
                            onClick={() => router.back()}
                            className="h-9 w-9 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300 active:scale-95 transition-transform"
                        >
                            <ArrowLeft className="h-4 w-4" />
                        </button>
                        <h1 className="font-bold text-[17px] text-slate-800 dark:text-slate-100">
                            {getPageTitle()}
                        </h1>
                    </>
                ) : isHome ? (
                    <div className="flex flex-col">
                        <span className="text-[10px] font-bold tracking-[0.15em] uppercase text-indigo-500 dark:text-indigo-400">{timeOfDay()}</span>
                        <h1 className="font-extrabold text-[20px] text-slate-900 dark:text-white tracking-tight leading-tight">
                            {user?.name?.split(' ')[0] || 'there'} 👋
                        </h1>
                    </div>
                ) : (
                    <div className="flex flex-col">
                        <span className="text-[10px] font-bold tracking-[0.15em] uppercase text-indigo-500 dark:text-indigo-400">SwasthSetu</span>
                        <h1 className="font-extrabold text-[19px] text-slate-900 dark:text-white tracking-tight leading-tight">
                            {getPageTitle()}
                        </h1>
                    </div>
                )}
            </div>

            <div className="relative z-10 flex items-center gap-2.5">
                {isHome && (
                    <Button variant="ghost" size="icon" className="relative h-10 w-10 rounded-2xl bg-slate-50 dark:bg-slate-900/80 border border-slate-100 dark:border-slate-800 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 transition-colors">
                        <Bell className="h-[18px] w-[18px]" />
                        <span className="absolute top-2 right-2 h-2 w-2 rounded-full bg-rose-500 border-2 border-white dark:border-slate-950" />
                    </Button>
                )}

                <DropdownMenu>
                    <DropdownMenuTrigger className="relative outline-none">
                        <Avatar className="h-10 w-10 flex-shrink-0 rounded-2xl ring-2 ring-indigo-500/20 hover:ring-indigo-500/40 transition-all cursor-pointer shadow-md">
                            <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${user?.name}`} className="object-cover" />
                            <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-violet-600 text-white text-sm font-bold rounded-2xl">
                                {getInitials(user?.name)}
                            </AvatarFallback>
                        </Avatar>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-60 mt-3 shadow-2xl shadow-indigo-500/10 rounded-2xl border border-slate-100 dark:border-slate-800 p-2 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl">
                        <DropdownMenuLabel className="font-normal p-3">
                            <div className="flex items-center gap-3">
                                <Avatar className="h-10 w-10 rounded-xl">
                                    <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${user?.name}`} />
                                    <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-violet-600 text-white text-xs font-bold rounded-xl">
                                        {getInitials(user?.name)}
                                    </AvatarFallback>
                                </Avatar>
                                <div>
                                    <p className="text-[14px] font-bold text-slate-900 dark:text-white leading-tight">{user?.name || 'Patient'}</p>
                                    <p className="text-[11px] font-medium text-slate-400 mt-0.5 truncate max-w-[130px]">{user?.email}</p>
                                </div>
                            </div>
                        </DropdownMenuLabel>
                        <DropdownMenuSeparator className="bg-slate-100 dark:bg-slate-800 my-1" />
                        <DropdownMenuItem className="cursor-pointer rounded-xl p-0 focus:bg-transparent">
                            <Link href="/app/profile" className="w-full flex items-center py-2.5 px-3 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors text-slate-700 dark:text-slate-300 rounded-xl gap-3">
                                <div className="h-8 w-8 rounded-xl bg-indigo-50 dark:bg-indigo-900/30 flex items-center justify-center">
                                    <UserIcon className="h-4 w-4 text-indigo-500" />
                                </div>
                                <span className="font-semibold text-[13px]">My Profile</span>
                            </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={handleLogout} className="cursor-pointer rounded-xl p-0 mt-1 focus:bg-transparent">
                            <div className="w-full flex items-center py-2.5 px-3 hover:bg-rose-50 dark:hover:bg-rose-900/20 transition-colors rounded-xl gap-3">
                                <div className="h-8 w-8 rounded-xl bg-rose-50 dark:bg-rose-900/20 flex items-center justify-center">
                                    <span className="text-[14px]">🚪</span>
                                </div>
                                <span className="font-semibold text-[13px] text-rose-600">Log Out</span>
                            </div>
                        </DropdownMenuItem>
                    </DropdownMenuContent>
                </DropdownMenu>
            </div>
        </header>
    );
}
